// Include form validation functions here
const movies=[
{title:'Avatar',boxOffice:'$2,787,965,087',active:'Yes',dol:'02/05/2019',genre:'Science Fiction',hasTeaser:'yes'},
{title:'The Avengers',boxOffice:'$5,787,955,085',active:'Yes',dol:'12/12/2018',genre:'Superhero',hasTeaser:'yes'},
{title:'Titanic',boxOffice:'$2,737,935,037',active:'No',dol:'05/30/2016',genre:'Romance',hasTeaser:'no'},
{title:'Jurassic World',boxOffice:'$6,787,935,587',active:'Yes',dol:'08/05/2006',genre:'Science Fiction',hasTeaser:'yes'},
{title:'Avaenger: End Game',boxOffice:'$2,750,987,086',active:'No',dol:'02/12/2019',genre:'Superhero',hasTeaser:'yes'}
];
const renderMovies=function(movies){
	let tbe1=document.querySelector("#moviesTable");
	movies.forEach(function(movie){
		
		let tre1=document.createElement('tr');
		
		let tde1=document.createElement('td');
		tde1.setAttribute('class','ttitle');
		tde1.textContent=movie.title;
		tre1.appendChild(tde1);
		
		let tde2=document.createElement('td');
		tde2.setAttribute('class','tboxoffice');
		tde2.textContent=movie.boxOffice;
		tre1.appendChild(tde2);
		
		let tde3=document.createElement('td');
		tde3.setAttribute('class','tactive');
		tde3.textContent=movie.active;
		tre1.appendChild(tde3);
		
		let tde4=document.createElement('td');
		tde4.setAttribute('class','tdol');
		tde4.textContent=movie.dol;
		tre1.appendChild(tde4);
		
		let tde5=document.createElement('td');
		tde5.setAttribute('class','tgenre');
		tde5.textContent=movie.genre;
		tre1.appendChild(tde5);
		
		let tde6=document.createElement('td');
		tde6.setAttribute('class','thasteaser');
		tde6.textContent=movie.hasTeaser;
		tre1.appendChild(tde6);
		
		let link=document.createElement("a");
        link.textContent="Edit";
        link.href="edit-movie.html?"+"title="+movie.title+"&boxOffice="+movie.boxOffice+"&active="+movie.active+"&dateofLaunch="+movie.dol+"&genre="+movie.genre+"&hasTeaser="+movie.hasTeaser;
        let tde7=document.createElement("td");
		tde7.setAttribute('class','thasteaser');
        tde7.appendChild(link);
		tre1.appendChild(tde7);
		
		tbe1.appendChild(tre1);
	})
}

const renderMoviesCustomer=function(movies){
	let tbe1=document.querySelector('#moviesTable');
	movies.forEach(function(movie){
		if(movie.active === 'Yes'){
			let tre1=document.createElement('tr');
			
			let tde1=document.createElement('td');
			tde1.setAttribute('class','ttitle');
			tde1.textContent=movie.title;
			tre1.appendChild(tde1);
			
			let tde2=document.createElement('td');
			tde2.setAttribute('class','tboxoffice');
			tde2.textContent=movie.boxOffice;
			tre1.appendChild(tde2);
			
			let tde5=document.createElement('td');
			tde5.setAttribute('class','tgenre');
			tde5.textContent=movie.genre;
			tre1.appendChild(tde5);
			
			let tde6=document.createElement('td');
			tde6.setAttribute('class','thasteaser');
			tde6.textContent=movie.hasTeaser;
			tre1.appendChild(tde6);
			
			let link=document.createElement("a");
			link.textContent="Add to favourite";
			link.href="movie-list-customer-notification.html";
			let tde7=document.createElement("td");
			tde7.setAttribute('class','taction');
			tde7.appendChild(link);
			tre1.appendChild(tde7);

			tbe1.appendChild(tre1);
		}
	})
}

const editMovie=function(){
	var getQueryString = function ( field, url ) {
		var href = url ? url : window.location.href;
		var reg = new RegExp( '[?&]' + field + '=([^&#]*)', 'i' );
		var string = reg.exec(href);
		return string ? string[1] : null;
	};

	var title = getQueryString("title");
	document.querySelector("#title").value = title

	var  boxOffice= getQueryString("boxOffice");
	document.querySelector("#gross").value = boxOffice

	var dol = getQueryString("dateofLaunch");
	document.querySelector("#dol").valueAsDate = new Date(dol)

	var active = getQueryString("active");
	
	if(active==="Yes")
		document.querySelector("#yes").checked = true
	else
		document.querySelector("#no").checked = true
	var hs = getQueryString("hasTeaser");
	if(hs==="yes")
		document.querySelector("#hasTeaser").checked = true
	else
		document.querySelector("#hasTeaser").checked = false
	var cat = getQueryString("genre");
	document.querySelector("#genre").value = cat;
}

const validation=function(){
	console.log("Inside validation");
	var title=document.forms['movieDetail']['title'].value;
	var boxoffice=document.forms['movieDetail']['boxOffice'].value;
	var genre=document.forms['movieDetail']['genre'].value;
	var active=document.forms['movieDetail']['active'].value;
	var dateOfLaunch=document.forms['movieDetail']['dateOfLaunch'].value;
	if(title == "" || title == null){
		alert("Title should not be empty.");
		return false;
	}
	else if(boxoffice == "" || boxoffice == null){
		alert("Box office should not be empty.");
		return false;
	}
	else if(genre == "" || genre == null){
		alert("Genre should not be empty.");
		return false;
	}
	else if(active == "" || active == null){
		alert("Please select whether the movie is in active or not.");
		return false;
	}
	else if(dateOfLaunch == "" || dateOfLaunch == null){
		alert("Please specify the date of launch of the movie.");
		return false;
	}
	return true;
}

const renderMoviesFavourites=function(movies){
	let tbe1=document.querySelector("#moviesTable");
	movies.forEach(function(movie){
		
		let tre1=document.createElement('tr');
		
		let tde1=document.createElement('td');
		tde1.setAttribute('class','ttitle');
		tde1.textContent=movie.title;
		tre1.appendChild(tde1);
		
		let tde2=document.createElement('td');
		tde2.setAttribute('class','tboxoffice');
		tde2.textContent=movie.boxOffice;
		tre1.appendChild(tde2);
		
		let tde5=document.createElement('td');
		tde5.setAttribute('class','tgenre');
		tde5.textContent=movie.genre;
		tre1.appendChild(tde5);
		
		let link=document.createElement("a");
        link.textContent="Delete ";
        link.href="favorites-notification.html";
        let tde7=document.createElement("td");
        tde7.appendChild(link);
		tre1.appendChild(tde7);
		
		tbe1.appendChild(tre1);
	})
}

console.log("Hello World!!!");
//Movie List Admin
let fromPage=document.querySelector('#id').value;
console.log(fromPage);
if(fromPage == 'admin')
	renderMovies(movies);
else if(fromPage == 'customer')
	renderMoviesCustomer(movies);
else if(fromPage == 'editMovie'){
	editMovie();
	validation();
}
else if(fromPage == 'favourite')
	renderMoviesFavourites(movies);
